const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

const db = mysql.createConnection({
    host: '34.209.99.170',  // Your DB IP
    user: 'scoreboardUSR',  // Your DB user
    password: 'houiafdafojdswfef3',  // Your DB password
    database: 'scoreboardMariaDB'  // Your database name
});

app.post('/saveTemplate', (req, res) => {
    const { color1, color2, image1, image2, sport, userID } = req.body;
    const query = `INSERT INTO your_table (color1, color2, image1, image2, sport, userID) VALUES (?, ?, ?, ?, ?, ?)`;

    db.execute(query, [color1, color2, image1, image2, sport, userID], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Error saving template');
        }
        res.send('Template saved successfully');
    });
});

const PORT = process.env.PORT || 3306;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
